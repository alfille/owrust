// Shared library code can go here if needed
